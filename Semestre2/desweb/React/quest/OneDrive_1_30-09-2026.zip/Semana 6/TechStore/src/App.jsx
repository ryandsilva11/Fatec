import Header from "./componetes/Header";
import Hero from "./componetes/Hero";
import Category from "./componetes/Category";
import ProductCard from "./componetes/ProductCard";
import products from "./data/products.js";
import { useState } from "react";
import "./App.css";
function App() {

  const [quantidade, setQuantidade] = useState(0);
  const [categoria, setCategoria] = useState('Todos');

  const produtosFiltrados =
  categoria === 'Todos'
    ? products
    : products.filter(
        product => product.categoria === categoria
      );


  function adicionarCarrinho() {
    setQuantidade(quantidade + 1);
  }


  return (
    <>
      <Header quantidade={quantidade}  />
      <Hero />
      <button onClick={() => setCategoria('Todos')}>
        Todos
      </button>

      <button onClick={() => setCategoria('Notebooks')}>
        Notebooks
      </button>

      <button onClick={() => setCategoria('Celulares')}>
        Celulares
      </button>

      {produtosFiltrados.map(product => (
        <ProductCard
          key={product.id}
          nome={product.nome}
          categoria={product.categoria}
          preco={product.preco}
          imagem={product.imagem}
          adicionarCarrinho={adicionarCarrinho} />
      ))}
      
      


    </>
  );
}

export default App;
