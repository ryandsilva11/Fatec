function Cart(props) {
  return (
    <aside className="cart">

      <h2>Meu Carrinho</h2>

      {props.produtos.length === 0 ? (
        <p>Seu carrinho está vazio.</p>
      ) : (
        props.produtos.map(produto => (
          <div key={produto.id}>
            <span>{produto.nome}</span>
          </div>
        ))
      )}

    </aside>
  );
}

export default Cart;
 

