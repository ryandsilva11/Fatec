function Header(props) {
  return (
    <header>
      <h1>TechStore</h1>

      <nav className="header">
        <a href="#">Início</a>
        <a href="#">Produtos</a>
        <a href="#">Ofertas</a>
        <a href="#">Contato</a>
      </nav>

      <button>
        🛒 Carrinho ({props.quantidade})
      </button>
    </header>
  );
}

export default Header;
